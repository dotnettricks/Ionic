export interface Todo {
    userId: number;
    title: string;
    completed: boolean;
}
